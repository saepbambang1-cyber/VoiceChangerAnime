package com.example.voicechanger

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var engine: VoiceEngine
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var pitchValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        start = findViewById(R.id.startButton)
        pitchValue = findViewById(R.id.pitchValue)

        engine = VoiceEngine()

        val effects = arrayOf(
            "🌸 Anime Cute",
            "🎀 Kawaii",
            "✨ Anime Girl",
            "🐰 Loli-style Cute",
            "💗 Soft Girl",
            "🔥 Tsundere",
            "🌙 Elegant Girl",
            "⚡ Energetic",
            "🎤 Idol Anime",
            "💫 Magical Girl",
            "Female Natural",
            "Clean"
        )
        val spinner = findViewById<Spinner>(R.id.effectSpinner)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, effects)

        val pitch = findViewById<SeekBar>(R.id.pitchSeek)
        pitch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val factor = 0.85f + p / 100f * 0.75f
                pitchValue.text = String.format("%.2fx", factor)
                engine.pitchFactor = factor
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val gain = findViewById<SeekBar>(R.id.gainSeek)
        gain.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                engine.gain = p / 50f
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                engine.effect = pos
                val presetPitch = when (pos) {
                    0 -> 1.38f  // Anime Cute
                    1 -> 1.45f  // Kawaii
                    2 -> 1.30f  // Anime Girl
                    3 -> 1.52f  // Loli-style Cute
                    4 -> 1.25f  // Soft Girl
                    5 -> 1.18f  // Tsundere
                    6 -> 1.10f  // Elegant Girl
                    7 -> 1.34f  // Energetic
                    8 -> 1.28f  // Idol Anime
                    9 -> 1.42f  // Magical Girl
                    10 -> 1.20f // Female Natural
                    else -> 1.00f
                }
                engine.pitchFactor = presetPitch
                pitch.progress = (((presetPitch - 0.85f) / 0.75f) * 100f)
                    .toInt().coerceIn(0, 100)
                pitchValue.text = String.format("%.2fx", presetPitch)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        start.setOnClickListener {
            if (!hasMicPermission()) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            } else {
                toggleEngine()
            }
        }
    }

    private fun hasMicPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED

    private fun toggleEngine() {
        if (engine.running) {
            engine.stop()
            status.text = "● OFF"
            start.text = "MULAI VOICE CHANGER"
        } else {
            engine.start()
            status.text = "● LIVE"
            start.text = "STOP VOICE CHANGER"
        }
    }

    override fun onDestroy() {
        engine.stop()
        super.onDestroy()
    }
}

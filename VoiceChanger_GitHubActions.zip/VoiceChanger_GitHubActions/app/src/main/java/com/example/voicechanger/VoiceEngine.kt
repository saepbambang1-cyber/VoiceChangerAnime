package com.example.voicechanger

import android.media.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Prototype real-time voice changer.
 *
 * Pipeline:
 * Microphone -> gain -> simple pitch/resample effect -> soft saturation ->
 * AudioTrack monitor.
 *
 * Important: changing sample positions is a lightweight pitch effect and also
 * changes playback timing. A production-quality pitch shifter should use
 * WSOLA/phase-vocoder DSP or a native DSP library.
 */
class VoiceEngine {
    @Volatile var pitchFactor = 1.30f
    @Volatile var gain = 1.0f
    @Volatile var effect = 0
    @Volatile var running = false

    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var thread: Thread? = null

    private val sampleRate = 44100
    private val bufferSize by lazy {
        val minIn = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        max(minIn, 4096)
    }

    fun start() {
        if (running) return

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            record = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize * 2
            )
        }

        val outBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        track = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build(),
            max(outBuffer, 4096),
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )

        running = true
        record?.startRecording()
        track?.play()

        thread = Thread {
            val input = ShortArray(bufferSize)
            val output = ShortArray(bufferSize)

            while (running) {
                val n = record?.read(input, 0, input.size) ?: 0
                if (n <= 0) continue

                process(input, output, n)
                track?.write(output, 0, n)
            }
        }.apply {
            name = "VoiceDSP"
            start()
        }
    }

    private fun process(input: ShortArray, output: ShortArray, n: Int) {
        val p = pitchFactor.coerceIn(0.85f, 1.60f)
        val g = gain.coerceIn(0f, 2f)

        for (i in 0 until n) {
            val source = (i * p).toInt().coerceIn(0, n - 1)
            var x = input[source].toFloat() * g

            val prev = if (i > 0) input[source.coerceAtLeast(1) - 1].toFloat() else 0f
            val diff = input[source].toFloat() - prev

            // Preset-specific lightweight tone shaping.
            x += when (effect) {
                0 -> diff * 0.26f       // Anime Cute
                1 -> diff * 0.34f       // Kawaii
                2 -> diff * 0.20f       // Anime Girl
                3 -> diff * 0.40f       // Loli-style Cute
                4 -> diff * 0.10f       // Soft Girl
                5 -> diff * 0.12f       // Tsundere
                6 -> diff * 0.06f       // Elegant Girl
                7 -> diff * 0.30f       // Energetic
                8 -> diff * 0.24f       // Idol Anime
                9 -> diff * 0.32f       // Magical Girl
                10 -> diff * 0.14f      // Female Natural
                else -> 0f
            }

            // Mild saturation/character for brighter anime presets.
            val y = (x / 32768f).coerceIn(-1f, 1f)
            val saturated = when (effect) {
                1, 3, 7, 8, 9 -> y * (1.12f - 0.12f * abs(y))
                5 -> y * (1.06f - 0.06f * abs(y))
                else -> y
            }

            output[i] = (saturated.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
    }

    fun stop() {
        running = false
        try { thread?.join(250) } catch (_: InterruptedException) {}
        thread = null

        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null

        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }
}

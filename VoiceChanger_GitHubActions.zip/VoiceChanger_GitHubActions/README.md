# Voice Changer Cewek — GitHub Actions build

Project Android native Kotlin dengan preset voice changer sederhana.

## Build APK tanpa AndroidIDE

1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini (bukan file ZIP sebagai satu file).
3. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
4. Push ke branch `main` atau jalankan workflow dari tab **Actions** dengan **Run workflow**.
5. Setelah selesai, buka hasil workflow dan download artifact **VoiceChanger-debug-apk**.
6. Di dalam artifact ada `app-debug.apk`.

## Catatan

- Build menggunakan JDK 17, Android SDK 35, Build Tools 35.0.0, dan Gradle 8.9.
- APK ini adalah prototype audio monitor/voice effect. Android biasa tidak menjamin output mic dapat menjadi virtual microphone untuk Mobile Legends atau aplikasi lain.
- Untuk voice changer real-time ke aplikasi lain diperlukan dukungan routing/virtual microphone yang tidak tersedia secara universal di Android.
